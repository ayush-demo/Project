import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { quiz } from 'src/app/interfaces/quiz';
import { QuizService } from 'src/app/services/quiz.service';

@Component({
  selector: 'app-quizes',
  templateUrl: './quizes.component.html',
  styleUrls: ['./quizes.component.scss']
})
export class QuizesComponent implements OnInit {

  //variable for storing all the quizes
  data:quiz[]=[];

  //variable for storing filtered quizes
  // quiz: quiz[]=[];

  //variable to store fetched id from param
  id:any;

  catId: any;

  constructor(private quizservice: QuizService, private route:ActivatedRoute) {
    
    this.id = this.route.snapshot.params.id;
    this.sendId();

    // //for fetching all the quizes
    // this.quizservice.getquizes().subscribe((ret:any[])=>{
    //   console.log("data fetched ", ret);
    //   this.data = ret;
    //   console.log("data array", this.data);
      
    // }) 

  }

  ngOnInit(): void {   

    //  //for filtering quizes
    //  this.route.paramMap.subscribe((p:ParamMap)=>{
    //   this.id =p.get("id");
    //   alert(this.id+ "Id found");
    //   this.quiz = this.data.filter((m)=> m.quize_cat_id==this.id);
    //   console.log("data array"+this.data);
    //   console.log(this.quiz+"filtered array");
      
    // })
  }

  //getting quiz by id
  sendId() {
    this.catId = this.id
    this.quizservice.getquizesbyid(this.catId).subscribe((ret: any[]) => {
      console.log(ret);
      this.data = ret;
    })
  }

}
