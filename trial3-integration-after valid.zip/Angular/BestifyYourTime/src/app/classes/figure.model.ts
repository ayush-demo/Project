export interface Figure {
  code: string;
  shape: number[][];
}
