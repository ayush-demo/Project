import { Component, OnInit, ViewChild, ElementRef, Input } from '@angular/core';
import { puzzle } from 'src/app/classes/puzzle';
import { PuzzleService } from 'src/app/services/puzzle.service';
import { ActivatedRoute, Router } from '@angular/router';
import { puzzleresult } from 'src/app/classes/puzzleresult';
import { user } from 'src/app/interfaces/user';
import { puzzleResult } from 'src/app/interfaces/puzzle_result';
import { PuzzlesService } from 'src/app/services/puzzles.service';

@Component({
  selector: 'app-showpuzzle',
  templateUrl: './showpuzzle.component.html',
  styleUrls: ['./showpuzzle.component.scss']
})
export class ShowpuzzleComponent implements OnInit {

  @ViewChild('op1') op1!: ElementRef;

  puzzle: any;
  @Input()
  score: number = 0;
  puzzle_Id: any;
  puzzle_Answer: any;
  //puzzle_Answerdb:any;
  answer: any;
  isCorrect: boolean | undefined;
  data: any;
  user_Id: number = 1;
  showanswer: boolean = false;



  users: user[] = [];
  user: user | undefined;

  // getting the id of user from local storage
  id: any = localStorage.getItem("user1");

  // An array to store all the Puzzle Result
  puzzlesResults: puzzleResult[] = [];

  // variable to store an specific puzzle Result field
  specificResult: puzzleResult | undefined;

  constructor(private puzzleService: PuzzleService, private route: ActivatedRoute, private r: Router, private puzzlesService: PuzzlesService) {

  }


  ngOnInit(): void {

    this.puzzleService.getData().subscribe(
      (response) => {                           //next() callback
        console.log('response received');
        console.log(response);
        this.puzzle = response;

      })


    //to get all the users 
    this.puzzlesService.getUsers().subscribe((ret: any[]) => {
      console.log(ret);
      this.users = ret;
    })
    // this.users= this.puzzleService.getUsers();

    // to get all the result from Puzzle result table
    this.puzzlesService.getPuzzleResult().subscribe((ret: any[]) => {
      console.log(ret);
      this.puzzlesResults = ret;
    })
  }

  @Input()
  public index: number = 1;
  next() {
    console.log('puzzlelength' + this.puzzle.length);
    if (this.puzzle.length >= this.index) {
      this.index++;
    }
  }


  checkAns(puzzle_idf: number) {
    var str: string = puzzle_idf.toString();
    // this.op1.nativeElement.innerHTML ="something";
    var id = <HTMLInputElement>document.getElementById(str);
    //console.log(Root);
    this.puzzle_Id = puzzle_idf;
    console.log(puzzle_idf);

    for (let i = 0; i < this.puzzle.length; i++) {
      if (this.puzzle[i].puzzle_id == puzzle_idf) {
        console.log(this.answer);
        console.log(this.puzzle[i].puzzle_answer);
        this.puzzle[i].isDisabled = true;
        console.log(puzzle_idf);
        console.log(this.puzzle[i].puzzle_id);
        if (this.answer === this.puzzle[i].puzzle_answer) {
          console.log('found');
          this.score = this.score + 1;
          id.innerHTML = 'Your Answer is Correct';
        } else {
          console.log('answer is incorrect');
          id.innerHTML =
            'Your Answer is Incorrect correct answer is ' +
            this.puzzle[i].puzzle_answer;
        }
      }
    }
  }

  post() {
    let currentDate = new Date().toISOString().slice(0, 10);
    const puzzleResults = new puzzleresult(this.user_Id, this.score, currentDate)
    this.puzzleService.postResult(puzzleResults).subscribe((puzzleResultRes) => {
      alert(puzzleResultRes);
    })

    console.log(this.score);
    this.r.navigate(['user']);

  }

  OnInput(event: any) {
    this.answer = event.target.value;
  }
  // sendId()
  // {
  //   this.puzzleService.getById(this.pId).subscribe((ret:any[])=>{
  //     this.data=ret;
  //     console.log(ret);
  //   })
  // }



  // submit(puzzle_id: number){
  submit() {

    this.post()
    // console.log(puzzle_id);

    console.log(this.id);
    this.user = this.users.find((m) => m.user_id == this.id);
    this.specificResult = this.puzzlesResults.find((m) => m.user_id == this.id);

    console.log(this.user);
    console.log(this.specificResult);

    this.puzzlesService.sendEmail("http://localhost:8080/api/puzzleresult/sendmail", this.user, this.specificResult).subscribe(
      data => {
        let res: any = data;
        console.log(`mail has been sent succesfully to ${this.user?.email} email Id. `);
      },
      err => {
        console.log(err);

      }
    );

  }

  show() {
    this.showanswer = true;
  }



}