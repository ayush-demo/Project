-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: bestify
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(255) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Quiz'),(2,'Games'),(3,'Puzzle');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favourites`
--

DROP TABLE IF EXISTS `favourites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favourites` (
  `fav_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `activity_id` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`fav_id`),
  UNIQUE KEY `actions_unique` (`user_id`,`activity_id`),
  KEY `activity_id` (`activity_id`),
  CONSTRAINT `favourites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `favourites_ibfk_2` FOREIGN KEY (`activity_id`) REFERENCES `quizzes` (`quiz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favourites`
--

LOCK TABLES `favourites` WRITE;
/*!40000 ALTER TABLE `favourites` DISABLE KEYS */;
INSERT INTO `favourites` VALUES (1,1,1,1,'2020-12-21 14:41:31','2020-12-21 14:41:31');
/*!40000 ALTER TABLE `favourites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_result`
--

DROP TABLE IF EXISTS `game_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_result` (
  `game_result_id` int(11) NOT NULL AUTO_INCREMENT,
  `game_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `finised` tinyint(1) DEFAULT NULL,
  `date_played` date DEFAULT NULL,
  PRIMARY KEY (`game_result_id`),
  KEY `game_id` (`game_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `game_result_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `games` (`game_id`),
  CONSTRAINT `game_result_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_result`
--

LOCK TABLES `game_result` WRITE;
/*!40000 ALTER TABLE `game_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `games`
--

DROP TABLE IF EXISTS `games`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `games` (
  `game_id` int(11) NOT NULL AUTO_INCREMENT,
  `game_name` varchar(255) NOT NULL,
  PRIMARY KEY (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `games`
--

LOCK TABLES `games` WRITE;
/*!40000 ALTER TABLE `games` DISABLE KEYS */;
/*!40000 ALTER TABLE `games` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `puzzle_result`
--

DROP TABLE IF EXISTS `puzzle_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `puzzle_result` (
  `puzzle_result_id` int(11) NOT NULL AUTO_INCREMENT,
  `puzzle_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `finised` tinyint(1) DEFAULT NULL,
  `date_played` date DEFAULT NULL,
  PRIMARY KEY (`puzzle_result_id`),
  KEY `puzzle_id` (`puzzle_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `puzzle_result_ibfk_1` FOREIGN KEY (`puzzle_id`) REFERENCES `puzzles` (`puzzle_id`),
  CONSTRAINT `puzzle_result_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `puzzle_result`
--

LOCK TABLES `puzzle_result` WRITE;
/*!40000 ALTER TABLE `puzzle_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `puzzle_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `puzzles`
--

DROP TABLE IF EXISTS `puzzles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `puzzles` (
  `puzzle_id` int(11) NOT NULL AUTO_INCREMENT,
  `puzzle_question` varchar(255) NOT NULL,
  `puzzle_answer` varchar(255) DEFAULT NULL,
  `puzzle_name` varchar(255) DEFAULT NULL,
  `puzzle_explanation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`puzzle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `puzzles`
--

LOCK TABLES `puzzles` WRITE;
/*!40000 ALTER TABLE `puzzles` DISABLE KEYS */;
INSERT INTO `puzzles` VALUES (1,'Puzzle 1','Puzzle 1','Puzzle 1',NULL);
/*!40000 ALTER TABLE `puzzles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_categories`
--

DROP TABLE IF EXISTS `quiz_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_categories` (
  `quiz_cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_cat_name` varchar(255) NOT NULL,
  PRIMARY KEY (`quiz_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_categories`
--

LOCK TABLES `quiz_categories` WRITE;
/*!40000 ALTER TABLE `quiz_categories` DISABLE KEYS */;
INSERT INTO `quiz_categories` VALUES (1,'Science'),(2,'Arts'),(3,'Technology');
/*!40000 ALTER TABLE `quiz_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_result`
--

DROP TABLE IF EXISTS `quiz_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_result` (
  `quize_result_id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `finised` tinyint(1) DEFAULT NULL,
  `date_played` date DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `out_off` int(11) DEFAULT NULL,
  PRIMARY KEY (`quize_result_id`),
  KEY `quiz_id` (`quiz_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `quiz_result_ibfk_1` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`quiz_cat_id`),
  CONSTRAINT `quiz_result_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_result`
--

LOCK TABLES `quiz_result` WRITE;
/*!40000 ALTER TABLE `quiz_result` DISABLE KEYS */;
INSERT INTO `quiz_result` VALUES (2,1,1,1,NULL,'2020-12-21',4,4),(3,1,3,0,NULL,'2020-12-21',2,4);
/*!40000 ALTER TABLE `quiz_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quizzes`
--

DROP TABLE IF EXISTS `quizzes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quizzes` (
  `quiz_id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_name` varchar(255) NOT NULL,
  `quiz_cat_id` int(11) NOT NULL,
  `questions` json NOT NULL,
  `quiz_time` int(11) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`quiz_id`),
  KEY `quiz_cat_id` (`quiz_cat_id`),
  CONSTRAINT `quizzes_ibfk_1` FOREIGN KEY (`quiz_cat_id`) REFERENCES `quiz_categories` (`quiz_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quizzes`
--

LOCK TABLES `quizzes` WRITE;
/*!40000 ALTER TABLE `quizzes` DISABLE KEYS */;
INSERT INTO `quizzes` VALUES (1,'Java Quiz',1,'[{\"quesId\": 1, \"option1\": \" a\", \"option2\": \" a\", \"option3\": \" a\", \"option4\": \" a\", \"question\": \"What if\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 2, \"option1\": \" a\", \"option2\": \" a\", \"option3\": \" a\", \"option4\": \" a\", \"question\": \"What if\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 3, \"option1\": \" a\", \"option2\": \" a\", \"option3\": \" a\", \"option4\": \" a\", \"question\": \"What if\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 4, \"option1\": \" a\", \"option2\": \" a\", \"option3\": \" a\", \"option4\": \" a\", \"question\": \"What if\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}]',60,'HAHAHAHAHAHAHAHHAHAHAHAHAHAHAHASDCFM ASDKFVSTVIULSRFWBVERVNRTVS'),(2,'Puzzle 1',1,'[{\"quesId\": 1, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 2, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 3, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 4, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}]',15,'Puzzle 1'),(3,'Puzzle 1',2,'[{\"quesId\": 1, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 2, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 3, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 4, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}]',15,'Puzzle 1'),(4,'Puzzle 1',3,'[{\"quesId\": 1, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 2, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 3, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 4, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}]',15,'Puzzle 1'),(5,'Puzzle 1',3,'[{\"quesId\": 1, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 2, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 3, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}, {\"quesId\": 4, \"option1\": \"Puzzle 1\", \"option2\": \"Puzzle 1\", \"option3\": \"Puzzle 1\", \"option4\": \"Puzzle 1\", \"question\": \"Puzzle 1\", \"correctAnswer\": \"a\", \"optionSelected\": \"\"}]',15,'Puzzle 1');
/*!40000 ALTER TABLE `quizzes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scores`
--

DROP TABLE IF EXISTS `scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scores` (
  `score_id` int(11) NOT NULL AUTO_INCREMENT,
  `game_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `score` int(11) NOT NULL,
  `date_played` date NOT NULL,
  PRIMARY KEY (`score_id`),
  KEY `game_id` (`game_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `scores_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `games` (`game_id`),
  CONSTRAINT `scores_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scores`
--

LOCK TABLES `scores` WRITE;
/*!40000 ALTER TABLE `scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `state` (
  `state_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `quiz` json DEFAULT NULL,
  `cat_id` int(11) NOT NULL,
  `timer` int(11) NOT NULL,
  PRIMARY KEY (`state_id`),
  KEY `user_id` (`user_id`),
  KEY `quiz_id` (`quiz_id`),
  KEY `cat_id` (`cat_id`),
  CONSTRAINT `state_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `state_ibfk_2` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`quiz_id`),
  CONSTRAINT `state_ibfk_3` FOREIGN KEY (`cat_id`) REFERENCES `quiz_categories` (`quiz_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `state`
--

LOCK TABLES `state` WRITE;
/*!40000 ALTER TABLE `state` DISABLE KEYS */;
/*!40000 ALTER TABLE `state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` tinyint(1) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'ayush','krushna','ayush@123','ayush@gmail.com','$2a$04$XN/RBqK0KNJdqw15gNJRcey1Gr.sRtuBiS8bJfvhW/8ngiwMx7RqW',0,'2020-12-21 14:10:10','2020-12-21 14:10:10'),(2,'admin','admin','admin@123','admin@gmail.com','$2a$04$cmv9obbYx2VAa/BFiWPpT.DwhrJXGaIDKQfIkbE00S0lfw3XG2jvW',1,'2020-12-21 14:18:27','2020-12-21 14:18:27'),(3,'chetan','raut','chetan@123','chetan@gmail.com','$2a$04$2Z9x8jZ7XZfbDRsPGSa0tudXObD00gbB8NUONz8MjICPiQ1pceaGS',0,'2020-12-21 14:19:56','2020-12-21 14:19:56');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-21 21:11:14
