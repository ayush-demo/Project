module.exports = app => {
    const fav = require("../controllers/favourite.controller");
  
    var router = require("express").Router();
  
    // Create a new Tutorial
    router.post("/", fav.create);

     // Retrieve all Tutorials
     router.get("/", fav.findAll);

     // Retrieve a single Tutorial with id
    router.get("/:id", fav.findOne);
  
  

    app.use('/api/favourites', router);
}