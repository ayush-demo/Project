export class puzzle{
   public puzzle_id!:number;
    public puzzle_question!: string;
    public puzzle_answer!: string;
    public puzzle_name!: string;
}