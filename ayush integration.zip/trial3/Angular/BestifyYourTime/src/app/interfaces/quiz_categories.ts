export interface quizCategories{
    quiz_cat_id:number;
    quiz_cat_name:string;
    cat_id:number;
}




