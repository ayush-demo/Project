import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showpuzzlelinks',
  templateUrl: './showpuzzlelinks.component.html',
  styleUrls: ['./showpuzzlelinks.component.scss']
})
export class ShowpuzzlelinksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
