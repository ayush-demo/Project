import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { games } from '../interfaces/games';

@Injectable({
  providedIn: 'root'
})
export class GamesService {

  //an instance for an games interface
  games: games[]=[];

  //api for fetching games from database
  private categoryUrl='http://localhost:8080/api/games'

  constructor(private httpClient: HttpClient) { }

  getGames(): Observable<games[]> {
    return this.httpClient.get<games[]>(this.categoryUrl)
  }
}
