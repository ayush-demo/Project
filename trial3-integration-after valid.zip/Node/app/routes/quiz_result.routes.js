module.exports = app => {
    const quizeresult = require("../controllers/quiz_result.controller");

    var router = require("express").Router();

    // Create a new Tutorial
    router.post("/", quizeresult.create);

    // Retrieve all Tutorials
    router.get("/", quizeresult.findAll);

    
    // Retrieve a single Tutorial with id
    router.get("/:id", quizeresult.findOne);
    
    // Retrieve Result 
    router.get("/ak/userid=:uid&quizid=:qid", quizeresult.findByQuizIDandUserID);

    router.post("/ak/:id", quizeresult.updateQuizResultByID);
    
    router.post("/sendmail", quizeresult.sendMail);

    app.use('/api/quizeresult', router);
}