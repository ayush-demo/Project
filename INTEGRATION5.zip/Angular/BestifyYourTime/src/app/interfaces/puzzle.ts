export interface puzzle {
    puzzle_id: number;
    puzzle_name:string;
    puzzle_answer:string;
    puzzle_question: string;
} 