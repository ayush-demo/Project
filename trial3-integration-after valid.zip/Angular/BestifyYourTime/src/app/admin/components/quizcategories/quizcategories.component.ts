import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { quizCategories } from 'src/app/interfaces/quiz_categories';
import { QuizService } from 'src/app/services/quiz.service';

@Component({
  selector: 'app-quizcategories',
  templateUrl: './quizcategories.component.html',
  styleUrls: ['./quizcategories.component.scss']
})
export class QuizcategoriesComponent implements OnInit {

  data:quizCategories[]=[];
  id:any;

  constructor(private quizservice: QuizService, private route:ActivatedRoute,private router: Router) { }

  ngOnInit(): void {
    this.quizservice.getQuizCat().subscribe((ret: any[])=>{
      console.log(ret);
      this.data = ret;
    }) 
  }

  // navigateToQuiz(id:number){
  //   alert(id);
  //   this.router.navigate(['/admin/quizes/:'+id]);
  // }

}
