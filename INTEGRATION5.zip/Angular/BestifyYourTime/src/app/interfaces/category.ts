export interface category {
    cat_id: number;
    cat_name: string;   
}    