module.exports = (sequelize, DataType) => {
    const PUZZLERESULT = sequelize.define("puzzle_result", {
      puzzle_result_id: {
        type: DataType.INTEGER,
        autoIncrement:true,
        primaryKey:true
      },
      puzzle_id:{
        type:DataType.INTEGER,
        allowNull:false,
        references:{
          model:'puzzles',
          key:'puzzle_id'
        }
      },
      user_id:{
        type:DataType.INTEGER,
        allowNull:false,
        references:{
          model:'users',
          key:'user_id'
        }
      },
      status:{
        type:DataType.BOOLEAN
      },
      finised:{
        type:DataType.BOOLEAN
      },
      date_played:{
        type: DataType.DATEONLY
      }
    },
    {
    freezeTableName:true,
    timestamps:false,
    underscored:true
    });
  
    return PUZZLERESULT;
  };