import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'timeToString'
})
export class TimeStringPipe implements PipeTransform {

  transform(time: number): string {
  let h:number=time/3600;
  let hours=Math.floor(h);
  let rem:number=time%3600;
  let m:number=rem/60;
  let min:number=Math.floor(m);
  let sec:number=rem%60;
  // console.log(h,hours,m,min,sec);
  let str:string="";

  if(hours===0){
    if(min===0){
      str=sec+" sec";
    } 
    else{
      str=min+" min "+sec+" sec";
    }   
  }
  else{
    str=hours+" hr "+min+" min "+sec+"sec";
  }

  return str;
  }

}
