import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './components/admin/admin.component';

import { Routes, RouterModule } from '@angular/router';
import { CategoriesComponent } from './components/categories/categories.component';
import { PuzzlesComponent } from './components/puzzles/puzzles.component';
import { QuizcategoriesComponent } from './components/quizcategories/quizcategories.component';
import { QuizesComponent } from './components/quizes/quizes.component';
import { AddPuzzleComponent } from './components/puzzles/add-puzzle/add-puzzle.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { QuizAddComponent } from './components/quiz-add/quiz-add.component';
import { QuizAddQuestionComponent } from './components/quiz-add-question/quiz-add-question.component';

import { MatTabsModule } from '@angular/material/tabs';

const routes: Routes = [
  {
    path: '', // localhost:4200/admin
    component: AdminComponent,
    children: [
      {
        path: 'categories',
        component: CategoriesComponent
      },
      {
        path: 'quizcategories',
        component: QuizcategoriesComponent
      },
      {
        path: 'puzzles',
        component: PuzzlesComponent,
        // children: [
        //           ]
      },
      {
        path: 'addpuzzle',
        component: AddPuzzleComponent
      },
      {
        path: 'addquiz',
        component: QuizAddComponent
      },
      {
        path: 'quizzes',
        component: QuizesComponent,
        children: [
          {
            path: ':id',
            component: QuizesComponent
          },
        ]
      }
    ]
  }
];

@NgModule({
  declarations: [
    AdminComponent,
    CategoriesComponent,
    PuzzlesComponent,
    AddPuzzleComponent,
    QuizcategoriesComponent,
    QuizesComponent,
    QuizAddComponent,
    QuizAddQuestionComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    HttpClientModule,
    MatTabsModule
  ]
})
export class AdminModule { }