import { Injectable } from '@angular/core';
import { Score } from '../classes/score';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ScoreService {

  url='http://localhost:8080/api/scores';
  constructor(private httpClient: HttpClient) { }

  postData(data:Score): Observable<Score> {
   console.log("Score from service  : " , data);
     return this.httpClient.post<Score>(this.url,data);
   }
}
