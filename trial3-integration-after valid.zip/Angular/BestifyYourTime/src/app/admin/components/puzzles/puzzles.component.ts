import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { puzzle } from 'src/app/classes/puzzles';
//import { puzzle } from 'src/app/interfaces/puzzle';
import { PuzzlesService } from 'src/app/services/puzzles.service';

@Component({
  selector: 'app-puzzles',
  templateUrl: './puzzles.component.html',
  styleUrls: ['./puzzles.component.scss']
})
export class PuzzlesComponent implements OnInit {
  puzzles: puzzle[]=[];
  puzzle!: puzzle;
  

  constructor(private puzzleService: PuzzlesService, private route: Router) { }

  ngOnInit(): void {

    this.puzzleService.getPuzzles().subscribe((ret: any[])=>{
      console.log(ret);
      this.puzzles = ret;
    }) 
  }

  addpuzzle()
  {
    console.log(this.puzzle);
    this.puzzleService.postData(this.puzzle).subscribe((reponse)=>{
      console.log(reponse);
      this.route.navigate(['admin']);
     }); 
    }

}
