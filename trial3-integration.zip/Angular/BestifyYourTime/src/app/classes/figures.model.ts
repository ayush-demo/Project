import { Figure } from './figure.model';

export interface Figures {
  figures: Figure[];
}

