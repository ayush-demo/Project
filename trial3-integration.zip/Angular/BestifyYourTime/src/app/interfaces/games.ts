export interface games {
    game_id: number;
    game_name:string;
    cat_id: number;    
} 