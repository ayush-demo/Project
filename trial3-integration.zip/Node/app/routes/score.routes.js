module.exports = app => {
    const score = require("../controllers/score.controller");
  
    var router = require("express").Router();
  
    // Create a new Tutorial
    router.post("/", score.create);

     // Retrieve all Tutorials
     router.get("/", score.findAll);

     // Retrieve a single Tutorial with id
    router.get("/:id", score.findOne);

    app.use('/api/scores', router);
}