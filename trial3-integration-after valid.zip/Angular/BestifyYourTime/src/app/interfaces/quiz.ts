export interface quiz{
    quiz_id:number;
    quiz_name:string;
    quiz_cat_id:number;
}
