import { Question } from "./Question"

export class Quiz{
    questions:Question[];
    quiz_name:string;
    quiz_cat_id:number;
    quiz_time:number;
    description:string;

    constructor(){
        this.questions=[];
        this.quiz_name='';
        this.quiz_cat_id=-1;
        this.quiz_time=0;
        this.description="";
    }
}