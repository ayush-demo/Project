const db = require("../models");
const scores = db.scores;
const Op = db.DataType.Op;

// Create and Save a new Tutorial
exports.create = (req, res) => {

    console.log("body " , req.body);
    // Validate request
    if (!req.body.score) {
      res.status(400).send({
        message: "Content can not be empty!"
      });
      return;
    }
  
    // Create a Tutorial
    const us = {
        game_id:req.body.game_id,
        user_id: req.body.user_id,
        score:req.body.score,
        //status:req.body.status,
        date_played:req.body.date_played,
        // start_time:req.body.start_time,
        // end_time:req.body.end_time
    };
  
    // Save Tutorial in the database
    scores.create(us)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the Tutorial."
        });
      });
  };
  //--------------------------------------------------------
// Retrieve all Tutorials from the database.
  exports.findAll = (req, res) => {
    const score_id = req.query.score_id;
    var condition = score_id ? { score_id: { [Op.like]: `%${score_id}%` } } : null;
  
    scores.findAll({ where: condition })
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving tutorials."
        });
      });
  };
//------------------------------------------------------------------------------------
// Find a single Tutorial with an id
exports.findOne = (req, res) => {
    const id = req.params.id;
  
    scores.findByPk(id)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message: "Error retrieving Tutorial with id=" + id
        });
      });
  };

