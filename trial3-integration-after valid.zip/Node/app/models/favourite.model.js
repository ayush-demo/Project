module.exports = (sequelize, DataType) => {
    const FAV = sequelize.define("favourites", {
      fav_id: {
        type: DataType.INTEGER,
        autoIncrement:true,
        primaryKey:true
      },
      user_id: {
        type: DataType.INTEGER,
        allowNull:false,
        references:{
            model:'users',
            key:'user_id'
          }
      },
      category_id: {
        type: DataType.INTEGER,
        allowNull:false,
        references:{
            model:'categories',
            key:'cat_id'
          }
      },

      // subcategory_id:{
      //   type: DataType.INTEGER,
      //   references :{
      //     model:'quize_categories',
      //     key:'quize_cat_id'
      //   }

      // },
      
      // quize_id: {
      //   type: DataType.INTEGER,
      //   allowNull:false,
      //   references:{
      //       model:'quizes',
      //       key:'quize_id'
      //     }
      // },
      // puzzle_id: {
      //   type: DataType.STRING,
      //   references:{
      //       model:'puzzles',
      //       key:'puzzle_id'
      //     }
      // },
      // game_id: {
      //   type: DataType.STRING,
      //   references:{
      //       model:'games',
      //       key:'game_id'
      //     }
      // } ,

      activity_id:{
        type: DataType.INTEGER,
        allowNull:false

      }
      
    },
    {
      uniqueKeys: {
          actions_unique: {
              fields: ['user_id', 'category_id', 'activity_id']
          }
      }
    },
    {
    freezeTableName:true,
    timestamps:false,
    underscored:true
    }
    );
  
    return FAV;
  };