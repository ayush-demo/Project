import { Component, OnInit } from '@angular/core';
import { Quiz } from 'src/app/classes/Quiz';
import { QuizaddService } from 'src/app/services/quizadd.service';
import { Question } from 'src/app/classes/Question';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-quiz-add',
  templateUrl: './quiz-add.component.html',
  styleUrls: ['./quiz-add.component.scss']
})
export class QuizAddComponent implements OnInit {

  quiz:Quiz=new Quiz();
  categories:any=[];

  someString:string="";
  testQuiz:Quiz;

  constructor(private quizAddService:QuizaddService) {
    this.testQuiz=new Quiz();
  }

  ngOnInit(): void {
    this.quizAddService.getQuizCategories().subscribe((data: any)=>{
      console.log(data);
      this.categories=data;
      this.categories.unshift({"quiz_cat_id": 0, quiz_cat_name: "SELECT", cat_id: 1});
    });
  }

  addQuestion() :void {
    this.quiz.questions.push(new Question);
  }

  onAddButtonClick(ques:string,op1:string,op2:string,op3:string,op4:string,co:string){
    //console.log("adding on button click");
    let q=new Question();
    q.question=ques;
    q.option1=op1;
    q.option2=op2;
    q.option3=op3;
    q.option4=op4;
    q.correctAnswer=co;
    this.quiz.questions.push(q);
    // console.log(q);
  }

  removeQuestion(index:number){
    //console.log(index);
    this.quiz.questions.splice(index,1);
  }

  submit(title:string,desc:string,cat:string,min:string,sec:string){
    
    //TODO : Add validations
    if(this.quiz.questions.length===0){
    alert("Add some questions");
    return;
    }

    this.addQuestionID(this.quiz);

    this.quiz.description=desc;
    this.quiz.quiz_name=title;
    this.quiz.quiz_time=parseInt(min)*60+parseInt(sec);
    this.quiz.quiz_cat_id=parseInt(cat);

    this.quizAddService.postQuiz(this.quiz)              
  }

  addQuestionID(quiz:Quiz){
    let count:number=1;
    quiz.questions.forEach(element => {
      element.quesId=count++;
    });
  }


}
