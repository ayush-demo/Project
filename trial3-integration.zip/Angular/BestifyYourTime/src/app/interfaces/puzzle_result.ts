export interface puzzleResult{
    puzzle_result_id:number;
    puzzle_id:number;
    user_id:number;
    status:boolean;
    finised:boolean;
    date_played:Date;
}